## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----read_tung, message=FALSE-------------------------------------------------
library(RCurl)
data_path <- "https://raw.githubusercontent.com/jdblischak/singleCellSeq/master/data/"
umi <- read.table(text=getURL(paste0(data_path, "molecules.txt")))
anno <- read.table(text=getURL(paste0(data_path,"annotation.txt")), sep = "\t", header = TRUE)

## ----input-quality-single-cells-----------------------------------------------
quality_single_cells <- scan(text=getURL(paste0(data_path,"quality-single-cells.txt")), 
                             what = "character")

## ----filter-cells-------------------------------------------------------------
umi.qc <- umi[, colnames(umi) %in% quality_single_cells]
anno.qc <- anno[anno$sample_id %in% quality_single_cells, ]

## ----table-exp, include=FALSE-------------------------------------------------
table(anno.qc$individual, anno.qc$replicate)

## ----replicates, echo=FALSE---------------------------------------------------
exp.design <- as.matrix(table(anno.qc$individual, anno.qc$replicate))
knitr::kable(exp.design, booktabs=TRUE, caption='Experimental design', row.names =TRUE)

## ----remove-non-expressed-genes-----------------------------------------------
umi.qc <- umi.qc[rowSums(umi.qc) > 0, ]
dim(umi.qc)

## ----get-spike-ins------------------------------------------------------------
spikes <- grep('ERCC', rownames(umi.qc))

## ----kBET---------------------------------------------------------------------
library(kBET)
patients <- unique(anno.qc$individual)
kBET.umi.counts <- list()
for (patient in patients){
  kBET.umi.counts[[patient]] <- kBET(df = umi.qc[-spikes,anno.qc$individual==patient], 
                                     batch = anno.qc$replicate[anno.qc$individual==patient],
                                     plot = FALSE)
}

## ----kBET_noN_summary, echo=FALSE---------------------------------------------
library(ggplot2)
library(gridExtra)

kBET.plots <- list()
for (patient in patients){
  plot.data <- data.frame(class = rep(c('observed', 'expected'), each=100), 
                          data = c(kBET.umi.counts[[patient]]$stats$kBET.observed,
                                   kBET.umi.counts[[patient]]$stats$kBET.expected))
  kBET.plots[[patient]] <- ggplot(plot.data, aes(class, data)) + 
                              geom_boxplot() + 
                              theme_bw() + 
                              labs(x='Test', y='Rejection rate',title=patient) + 
                              scale_y_continuous(limits=c(0,1))
}

n <- length(kBET.plots)
do.call("grid.arrange", c(kBET.plots, ncol=n))

## ----return-significance,echo=FALSE-------------------------------------------
summary.kBET <- kBET.umi.counts[[patients[1]]]$summary
summary.kBET$kBET.expected <- signif(summary.kBET$kBET.expected, digits = 2)
summary.kBET$kBET.observed <- signif(summary.kBET$kBET.observed, digits = 2)
colnames(summary.kBET) <- c('kBET (null model)', 'kBET (observed)', 'kBET p_value')
knitr::kable(summary.kBET, 
      booktabs=TRUE, caption=paste0('Summary for ', patient[[1]]), row.names=TRUE)

## ----visualise-umi-reads, echo=FALSE------------------------------------------
library(ggplot2)
pca.umis <- prcomp(log10(1+t(umi.qc[-spikes,])))
pca.df <- data.frame(PC1=pca.umis$x[,1], 
                     PC2=pca.umis$x[,2], 
                     replicate= anno.qc$replicate, 
                     patient=anno.qc$individual)
ggplot(pca.df, aes(x=PC1, y=PC2, shape=replicate, colour=patient)) + geom_point() + theme_bw() +
  ggtitle(expression(PCA * ' '* of* ' '* log[10]-normalised * ' '*raw* ' '* counts.))

## ----compute_hvg--------------------------------------------------------------
suppressPackageStartupMessages(library(M3Drop))
hvg.patient <- list()
hvg.overlap <- list()
for (patient in patients){
  
  hvg.patient[[patient]] <- list()
  data.subset <-umi.qc[-spikes,anno.qc$individual==patient]
  batch.subset <- anno.qc$replicate[anno.qc$individual==patient]
  batch.subset.ID <- unique(batch.subset)
  
  #compute highly variable genes per batch
  for (replicate in batch.subset.ID){
    hvg.patient[[patient]][[replicate]] <- 
      BrenneckeGetVariableGenes(data.subset[, batch.subset==replicate], 
                                suppress.plot = TRUE)
  }
  #compute intersection of highly variable genes in all batches
  hvg.overlap[[patient]] <- Reduce(intersect, hvg.patient[[patient]])
  #compute highly variable genes neglecting the batch effect
  hvg.patient[[patient]][['all']]<- BrenneckeGetVariableGenes(data.subset,
                                                              suppress.plot = TRUE)
} 

## ----venn_diag, echo=FALSE----------------------------------------------------
suppressPackageStartupMessages(library(grid))
suppressPackageStartupMessages(library(gridBase))
suppressPackageStartupMessages(library(gridGraphics))
suppressPackageStartupMessages(library(VennDiagram))
for (patient in patients){
  grid.newpage()
  vp <- venn.diagram(hvg.patient[[patient]], 
                      fill = rev(1:length(hvg.patient[[patient]])), 
                      alpha = 0.3, filename = NULL, main = patient)
  grid.draw(vp)
}
#plot overlap of the replicates
 # print(patient)
  #venn::venn(hvg.patient[[patient]], snames = colnames(batch.subset.ID), 
  #           zcolor = 'style', cexil=1.5)


## ----compute_FPR--------------------------------------------------------------
FPR <- list()
for (patient in patients){
  batch.subset.ID <- droplevels(unique(anno.qc$replicate[anno.qc$individual==patient]))
  inters <- sapply(batch.subset.ID, 
                  function(batch, set, patient){intersect(set[[patient]][['all']], 
                                                          set[[patient]][[batch]])}, 
                  hvg.patient, patient)
  FPR[[patient]] <- 1- length(Reduce(union, inters))/length(hvg.patient[[patient]][['all']])
}

## ----display_FPR, echo=FALSE--------------------------------------------------
plot.FPR <- data.frame(patient=names(unlist(FPR)), FPR=round(unlist(FPR),3))
knitr::kable(plot.FPR, booktabs=TRUE, caption='False positive rates for batch effects in not normalised data', row.names = FALSE)

## ----normalise-cpm------------------------------------------------------------
umi.cpm <- apply(umi.qc, 2, function(x,spikes){x/sum(x[-spikes])*1e6}, spikes)


## ----kBET-cpm-----------------------------------------------------------------
library(kBET)
patients <- unique(anno.qc$individual)
kBET.umi.cpm <- list()
for (patient in patients){
  kBET.umi.cpm[[patient]] <- kBET(df = umi.cpm[-spikes,anno.qc$individual==patient], 
                                  batch = anno.qc$replicate[anno.qc$individual==patient],
                                  plot = FALSE)
}

## ----kBET_CPM_summary, echo=FALSE---------------------------------------------
library(ggplot2)
library(gridExtra)

kBET.plots <- list()
for (patient in patients){
  plot.data <- data.frame(class = rep(c('observed', 'expected'), each=100), 
                          data = c(kBET.umi.cpm[[patient]]$stats$kBET.observed,
                                   kBET.umi.cpm[[patient]]$stats$kBET.expected))
  kBET.plots[[patient]] <- ggplot(plot.data, aes(class, data)) + 
                              geom_boxplot() + 
                              theme_bw() + 
                              labs(x='Test', y='Rejection rate',title=patient) + 
                              scale_y_continuous(limits=c(0,1))
}

n <- length(kBET.plots)
do.call("grid.arrange", c(kBET.plots, ncol=n))

## ----visualise-umi-cpm, echo=FALSE--------------------------------------------
library(ggplot2)
pca.umis <- prcomp(log10(1+t(umi.cpm[-spikes,])))
pca.df <- data.frame(PC1=pca.umis$x[,1], 
                     PC2=pca.umis$x[,2], 
                     replicate= anno.qc$replicate, 
                     patient=anno.qc$individual)
ggplot(pca.df, aes(x=PC1, y=PC2, shape=replicate, colour=patient)) + geom_point() + theme_bw() +
  ggtitle(expression(PCA * ' '* of* ' '* log[10]-CPM-normalised * ' '*data.))

## ----compute_hvg_cpm, echo=FALSE----------------------------------------------
library(M3Drop)
hvg.patient <- list()
hvg.overlap <- list()
for (patient in patients){
  
  hvg.patient[[patient]] <- list()
  data.subset <-umi.cpm[-spikes,anno.qc$individual==patient]
  batch.subset <- anno.qc$replicate[anno.qc$individual==patient]
  batch.subset.ID <- unique(batch.subset)
  
  #compute highly variable genes per batch
  for (replicate in batch.subset.ID){
    hvg.patient[[patient]][[replicate]] <- 
      BrenneckeGetVariableGenes(data.subset[, batch.subset==replicate], 
                                suppress.plot = TRUE)
  }
  #compute intersection of highly variable genes in all batches
  hvg.overlap[[patient]] <- Reduce(intersect, hvg.patient[[patient]])
  #compute highly variable genes neglecting the batch effect
  hvg.patient[[patient]][['all']]<- BrenneckeGetVariableGenes(data.subset,
                                                              suppress.plot = TRUE)
}

## ----venn_diag_cpm, echo=FALSE------------------------------------------------
 for (patient in patients){
  grid.newpage()
  vp <- venn.diagram(hvg.patient[[patient]], 
                      fill = rev(1:length(hvg.patient[[patient]])), 
                      alpha = 0.3, filename = NULL, main = patient)
  grid.draw(vp)

}

## ----compute_FPR2, echo=FALSE-------------------------------------------------
FPR <- list()
for (patient in patients){
  batch.subset.ID <- droplevels(unique(anno.qc$replicate[anno.qc$individual==patient]))
  inters <- sapply(batch.subset.ID, 
                  function(batch, set, patient){intersect(set[[patient]][['all']], set[[patient]][[batch]])}, 
                  hvg.patient, patient)
  FPR[[patient]] <- 1- length(Reduce(union, inters))/length(hvg.patient[[patient]][['all']])
}

## ----display_FPR2, echo=FALSE-------------------------------------------------
plot.FPR <- data.frame(patient=names(unlist(FPR)), FPR=round(unlist(FPR),3))
knitr::kable(plot.FPR, booktabs=TRUE, caption='False positive rates for batch effects in CPM-normalised data', row.names = FALSE)

## ----run_limma----------------------------------------------------------------
library(limma) 
y.limma <- lapply(patients, 
                   function(idx,data,batch, individual){
                       limma::removeBatchEffect(data[,individual==idx],
                                                batch = batch[individual==idx])
                   }, 
                   umi.qc[-spikes,], anno.qc$replicate, anno.qc$individual)


## ----run_kBET_limma-----------------------------------------------------------
kBET.limma<- lapply(1:length(patients),
                    function(idx, data,batch,individual,patients){
                      print(patients[idx]);
                      kBET(data[[idx]], batch[individual==patients[idx]], 
                           plot=FALSE, verbose=TRUE)},
                    y.limma, anno.qc$replicate, anno.qc$individual,patients)

## ----kBET_limma_plot, echo=FALSE----------------------------------------------
kBET.plots <- list()
for (patient in 1:length(patients)){
  plot.data <- data.frame(class = rep(c('observed', 'expected'), each=100),
                          data = c(kBET.limma[[patient]]$stats$kBET.observed,
                                   kBET.limma[[patient]]$stats$kBET.expected))
  kBET.plots[[patient]] <- ggplot(plot.data, aes(class, data)) +
    geom_boxplot() +
    theme_bw() +
    labs(x='Test', y='Rejection rate',title=patients[patient]) +
    scale_y_continuous(limits=c(0,1))
}

n <- length(kBET.plots)
do.call("grid.arrange", c(kBET.plots, ncol=n))


## ----display_signif, echo=FALSE-----------------------------------------------
p.values <- sapply(1:length(patients), function(x,data){data[[x]]$summary$kBET.signif[1]},kBET.limma)
plot.signif <- data.frame(patient=patients, p_value=signif(unlist(p.values),3))
knitr::kable(plot.signif, booktabs=TRUE, caption='Significance of batch effect after applying limma', row.names = FALSE)

## ----compute_hvg_limma, echo=FALSE--------------------------------------------
library(M3Drop)
hvg.patient <- list()
hvg.overlap <- list()
for (patient in patients){
  
  hvg.patient[[patient]] <- list()
  data.subset <-y.limma[[which(patients%in% patient)]]
  batch.subset <- anno.qc$replicate[anno.qc$individual==patient]
  batch.subset.ID <- unique(batch.subset)
  
  #compute highly variable genes per batch
  for (replicate in batch.subset.ID){
    hvg.patient[[patient]][[replicate]] <- 
      BrenneckeGetVariableGenes(data.subset[, batch.subset==replicate], 
                                suppress.plot = TRUE)
  }
  #compute intersection of highly variable genes in all batches
  hvg.overlap[[patient]] <- Reduce(intersect, hvg.patient[[patient]])
  #compute highly variable genes neglecting the batch effect
  hvg.patient[[patient]][['all']]<- BrenneckeGetVariableGenes(data.subset,
                                                              suppress.plot = TRUE)
  
}

for (patient in patients){
  grid.newpage()
  vp <- venn.diagram(hvg.patient[[patient]], 
                      fill = rev(1:length(hvg.patient[[patient]])), 
                      alpha = 0.3, filename = NULL, main = patient)
  grid.draw(vp)
}

## ----compute_FPR_limma, echo=FALSE--------------------------------------------
FPR <- list()
for (patient in patients){
  batch.subset.ID <- droplevels(unique(anno.qc$replicate[anno.qc$individual==patient]))
  inters <- sapply(batch.subset.ID, 
                  function(batch, set, patient){intersect(set[[patient]][['all']], set[[patient]][[batch]])}, 
                  hvg.patient, patient)
  FPR[[patient]] <- 1- length(Reduce(union, inters))/length(hvg.patient[[patient]][['all']])
}

## ----display_FPR_limma, echo=FALSE--------------------------------------------
plot.FPR <- data.frame(patient=names(unlist(FPR)), FPR=signif(unlist(FPR),3))
knitr::kable(plot.FPR, booktabs=TRUE, caption='False positive rates for batch effects in limma-corrected data', row.names = FALSE)

