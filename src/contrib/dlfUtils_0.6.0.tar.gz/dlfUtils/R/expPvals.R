


expPvals <- function(pvals) {
  (rank(pvals, ties.method = "first") + 0.5)/(length(pvals) + 1)
}

