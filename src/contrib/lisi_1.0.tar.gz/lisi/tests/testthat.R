library(testthat)
library(lisi)

test_check("lisi")
