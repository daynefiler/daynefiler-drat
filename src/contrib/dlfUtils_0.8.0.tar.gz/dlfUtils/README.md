# dlfUtils
R package with assortment of utility functions I use often. 

To install the current development version run the following command:		

      devtools::install_github("daynefiler/dlfUtils", dependencies = TRUE)
